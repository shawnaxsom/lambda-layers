def custom_function():
    print("Hello from Lambda Layers!")
    return "Success!"
